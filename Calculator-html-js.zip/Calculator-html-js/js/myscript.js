function clicked(ele){
    var previousValue = $('.answer').val();
    var clickedValue = $(ele).html();
    $('.answer').val(previousValue+clickedValue);
}

function operate(ele){
    firstNumber = $('.answer').val();
    process = $(ele).html();
    $('.answer').val(firstNumber+process);
}

function solve(){
    var question=$('.answer').val()
    secondNumber=question.slice(firstNumber.length+process.length)
    $('.history').val(question+"=");
    if(process=='+'){
        $('.answer').val(parseFloat(firstNumber)+parseFloat(secondNumber))
    }
    else if(process=='-'){
        $('.answer').val(parseFloat(firstNumber)-parseFloat(secondNumber))
    }
    else if(process=='x'){
        $('.answer').val(parseFloat(firstNumber)*parseFloat(secondNumber))
    }
    else if(process=='/'){
        $('.answer').val(parseFloat(firstNumber)/parseFloat(secondNumber))
    }
    else if(process=='^'){
        $('.answer').val(parseFloat(firstNumber)**parseFloat(secondNumber))
    }
    else if(process=='%'){
        $('.answer').val(parseFloat(firstNumber)%parseFloat(secondNumber))
    }
}

function backSpace(){
    var previousValue=$('.answer').val();
    $('.answer').val(previousValue.slice(0,previousValue.length-1));
}

function deletAll(){
    $('.answer').val("");
    $('.history').val("");
}