function pyramid(){
    document.getElementById('tochange').innerHTML="";
    var width = document.getElementById('width').value;
    for(a=1; a<=width; a++){
        for(b=1; b<=a; b++){
            document.getElementById('tochange').innerHTML+="*   ";

        }
        document.getElementById('tochange').innerHTML+='<br/>';
     }
     }