function box(){
    var columns = document.getElementById('columns').value;
    var rows = document.getElementById('rows').value;
    for(a=1; a<=rows; a++){
        for(b=1; b<=columns; b++){
            document.getElementById('tochange').innerHTML+="   *   ";
        }
        document.getElementById('tochange').innerHTML+='<br/>';
    }
}