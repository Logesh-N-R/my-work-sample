function triangle(){
    document.getElementById('tochange').innerHTML="";
    name = document.getElementById('input').value.toUpperCase();
    len = name.length;
    for(var i=1; i<=len; i++){
        document.getElementById('tochange').innerHTML+= name.slice(0,i);
        document.getElementById('tochange').innerHTML+='<br>';
        }
    for(var i=len; i>=0; i--){
        document.getElementById('tochange').innerHTML+= name.slice(0,i);
        document.getElementById('tochange').innerHTML+='<br>';
    }
}