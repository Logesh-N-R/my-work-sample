function filter(){
    var text = document.getElementById('input').value.toUpperCase();
    var name = document.getElementById('test').innerHTML.toUpperCase();
    var index = name.indexOf(text);
    
    if(index >= 0){
        name =  name.substring(0,index)+'<span>'+name.substring(index,index+text.length)+'</span>'+name.substring(index+text.length);
        document.getElementById('test').innerHTML=name;
    }
    return false;
}
