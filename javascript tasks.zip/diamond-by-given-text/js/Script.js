function triangle(){
    document.getElementById('tochange').innerHTML="";
    name = document.getElementById('input').value.toUpperCase();
    len = name.length;
    for(var i=1; i<=len; i++){
        for(var j=len; j>i; j--){
        document.getElementById('tochange').innerHTML+= "&nbsp;";
        }
        document.getElementById('tochange').innerHTML+= name.slice(0,i);
        document.getElementById('tochange').innerHTML+='<br>';
        }
    for(var i=len-1; i>=0; i--){
        for(var j=i; j<len; j++){
        document.getElementById('tochange').innerHTML+= "&nbsp;";
        }
        document.getElementById('tochange').innerHTML+= name.slice(0,i);
        document.getElementById('tochange').innerHTML+='<br>';
    }
} 