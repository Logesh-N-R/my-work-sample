$('document').ready(function(){
    $('.contextmenu').contextmenu(function(){
        console.log('hi');
        $('.content').css("visibility","visible");
    });
});


$(document).ready(function (e) {

    $('#A').click(function (e) { //Default mouse Position 
        $(".output").html(e.pageX + ' , ' + e.pageY);
    });

    $('#B').click(function (e) { //Offset mouse Position
        var posX = $(this).offset().left,
            posY = $(this).offset().top;
        $(".output").html((e.pageX - posX) + ' , ' + (e.pageY - posY));
    });

    $('#C').click(function (e) { //Relative ( to its parent) mouse position 
        var posX = $(this).position().left,
            posY = $(this).position().top;
        $(".output").html((e.pageX - posX) + ' , ' + (e.pageY - posY));
    });
});