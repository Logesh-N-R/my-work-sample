var number=1;
setInterval(function(){
    document.getElementById('radio-' + number).checked = true;
    number++;
    if(number > 4){
        number = 1;
    }
},5000);