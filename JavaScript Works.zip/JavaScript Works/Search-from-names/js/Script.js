function caps() {
	nameArr = document.getElementsByTagName("li");
	for (a = 0; a < nameArr.length; a++) {
		capitalName = nameArr[a].innerHTML.toUpperCase();
		nameArr[a].innerHTML = capitalName;
		nameArr[a].style.display = "none";
	}
}

function filter() {
	text = document.getElementById('input').value.toUpperCase();
	list = document.getElementById('nameList');
	listArr = list.getElementsByTagName('li');
	for (i = 0; i < listArr.length; i++) {
		let matchText = listArr[i].innerText.toUpperCase();
		let index = matchText.indexOf(text);
		if (index > -1) {
			listArr[i].style.display = "";
			matchText = matchText.substring(0, index) + '<span>' + matchText.substring(index, index + text.length) + '</span>' + matchText.substring(index + text.length);
			listArr[i].innerHTML = matchText;
		} else {
			listArr[i].style.display = "none";
		}
	}
}
