function total(){
    X();
    Y();
    Z();
    A();
    return false;
}
function X() {
    var x = document.forms["ex"]["fname"].value;
    if (x == "") {
    document.getElementById("FN").style="visibility: visible;";
    document.getElementById("fn").style='color:red;border:1px solid red;';
  }
    else{
       document.getElementById("fn").style='color:green;border:1px solid green;';
        document.getElementById("FN").style="visibility: hidden;";
    }
}


function Y() {
    var y = document.forms["ex"]["lname"].value;
    if (y == "") {
    document.getElementById("LN").style="visibility: visible;";
    document.getElementById("ln").style='color:red;border:1px solid red;';
  }
        else{
       document.getElementById("ln").style='color:green;border:1px solid green;'; 
        document.getElementById("LN").style="visibility: hidden;";
    }
}

function Z() {
    var z = document.forms["ex"]["mail"].value;
    if (z == "") {
    document.getElementById("Mail").style="visibility: visible;";
    document.getElementById("mail").style='color:red;border:1px solid red;';
  }
        else{
       document.getElementById("mail").style='color:green;border:1px solid green;'; 
        document.getElementById("Mail").style="visibility: hidden;";
    }
}
function A() {
    var a = document.forms["ex"]["date"].value;
    if (a == "") {
    document.getElementById("Date").style="visibility: visible;";
    document.getElementById("date").style='color:red;border:1px solid red;';
  }
        else{
       document.getElementById("date").style='color:green;border:1px solid green;'; 
        document.getElementById("Date").style="visibility: hidden;";
    }
}

