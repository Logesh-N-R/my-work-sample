function clicked(ele){
    var previousValue = $('.answer').val();
    var clickedValue = $(ele).html();
    $('.answer').val(previousValue+clickedValue);
    $('.calculated').val(eval($('.answer').val()));
}

function operate(ele){
    firstNumber = $('.answer').val();
    process = $(ele).html();
    splittedArr = firstNumber.split("-").join("+").split("*").join("+").split("/").join("+").split("%").join("+").split("^").join("+").split("+");
    arrLen = splittedArr.length;
    $('.answer').val(firstNumber+process);
    
    if(splittedArr[1]==""){
        $('.answer').val(splittedArr[0]+process);
        firstNumber=splittedArr[0];
    }
    if(splittedArr.length>=2){
        solved=eval(firstNumber);
        $('.calculated').val(solved+process);
        firstNumber=eval(firstNumber);
    }
    
}

function solve(){
    question=$('.answer').val();
    Arr = question.split("-").join("+").split("*").join("+").split("/").join("+").split("%").join("+").split("^").join("+").split("+");
    secondNumber=Arr[Arr.length-1];
    $('.history').val(question+"=");
    if(process=='+'){
        $('.answer').val(parseFloat(firstNumber)+parseFloat(secondNumber));
    }
    else if(process=='-'){
        $('.answer').val(parseFloat(firstNumber)-parseFloat(secondNumber));
    }
    else if(process=='*'){
        $('.answer').val(parseFloat(firstNumber)*parseFloat(secondNumber));
    }
    else if(process=='/'){
        $('.answer').val(parseFloat(firstNumber)/parseFloat(secondNumber));
    }
    else if(process=='^'){
        $('.answer').val(parseFloat(firstNumber)**parseFloat(secondNumber));
    }
    else if(process=='%'){
        $('.answer').val(parseFloat(firstNumber)%parseFloat(secondNumber));
    }    
}

function backSpace(){
    var previousValue=$('.answer').val();
    $('.answer').val(previousValue.slice(0,previousValue.length-1));
}

function deletAll(){
    $('.answer').val("");
    $('.history').val("");
    $('.calculated').val("");
}